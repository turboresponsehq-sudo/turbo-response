from pathlib import Path
from playwright.sync_api import sync_playwright
import json
BASE=Path(__file__).parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for w,h in [(1440,900),(900,700),(390,844)]:
  page=b.new_page(viewport={'width':w,'height':h})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  html=(BASE/'public/index.html').read_text().replace('<link rel="stylesheet" href="/styles.css">','').replace('<script src="/map-app.js" defer></script>','')
  page.set_content(html);page.add_style_tag(content=(BASE/'public/styles.css').read_text())
  ev=json.loads((BASE/'data/evidence.json').read_text());geo=json.loads((BASE/'public/georgia-counties-fallback.json').read_text())
  metrics={'year':2024,'sourceMode':'documented-examples-only','sourceAvailable':False,'counties':{'13121':{'firearmHomicides':{'deaths':181,'rate':16.8,'modeled':False,'year':2024,'county_fips':'13121'}}}}
  obj={'/georgia-counties-fallback.json':geo,'/api/v1/map/counties':geo,'/api/v1/evidence':{'statistics':ev['statistics'],'sources':ev['sources']},'/api/v1/funding':{'funding':ev['funding']},'/api/v1/county-metrics?year=2024':metrics,'/api/v1/county-injury-visits?year=2024':{'year':2024,'counties':{'13121':{'erVisitsNoAdmission':7,'crudeRate':0.6}}}}
  page.evaluate('''(responses)=>{window.fetch=async(url)=>{const d=responses[url];return d?{ok:true,json:async()=>d}:{ok:false,status:503,json:async()=>({error:'unavailable'})}}}''',obj)
  page.add_script_tag(content=(BASE/'public/map-app.js').read_text());page.wait_for_timeout(250)
  page.locator('#geo-search').fill('Fulton');page.locator('#geo-search').press('Enter');page.wait_for_timeout(800)
  t=page.locator('#detail-content').inner_text()
  assert 'Fulton County' in t,t[:300]
  assert '181' in t,t[:300]
  assert 'SOURCE NOTE' in t
  y=page.evaluate('window.scrollY')
  if w<=800:
   assert y>0, f'Expected scroll to county panel on mobile, saw {y}'
   top=page.locator('#detail-panel').bounding_box()['y']
   assert top<200, f'County panel not visible at top, y={top}'
  page.locator('#geo-search').fill('Appling');page.locator('#geo-search').press('Enter');page.wait_for_timeout(800)
  t=page.locator('#detail-content').inner_text()
  assert 'Appling County' in t and 'RETRY DATA CONNECTION' in t,t[:500]
  assert '181' not in t,t[:350]
  assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+1')
  assert errors==[],errors
  print('BROWSER',w,'Fulton 181 source-backed; Appling unavailable honest; mobile auto-scroll; no JS errors PASS')
  page.screenshot(path=str(BASE/f'v4-preview-{w}.png'),full_page=False)
  page.close()
 b.close()
