'use strict';
let evidence=[];let sources=[];let funding=[];let stakeholders=[];
const $=sel=>document.querySelector(sel), $$=sel=>[...document.querySelectorAll(sel)];
const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const findSource=id=>sources.find(s=>s.id===id);
const shortMoney=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(n);
let activeTab='pulse';
function chooseTab(id,scroll=false){
  if(!$('#panel-'+id))return;
  activeTab=id;
  $$('[role=tab]').forEach(t=>{const on=t.dataset.tab===id;t.setAttribute('aria-selected',on);t.tabIndex=on?0:-1});
  $$('.experience').forEach(el=>{el.hidden=el.id!=='panel-'+id;el.classList.toggle('active',!el.hidden)});
  if(scroll){$('.experience-nav').scrollIntoView({behavior:'smooth',block:'start'});}
  if(location.hash!==`#${id}`)history.replaceState(null,'',`#${id}`);
}
function showSources(id,scroll=true){
 const el=$('#sources');el.hidden=false;
 if(scroll)el.scrollIntoView({behavior:'smooth',block:'start'});
 if(id){setTimeout(()=>{const card=document.getElementById('src-'+id);if(card){card.style.borderColor='#d1f966';setTimeout(()=>card.style.borderColor='',1800)}},300)}
}
function renderEvidence(filter='all'){
 const list=filter==='all'?evidence:evidence.filter(x=>x.category===filter);
 $('#pulse-cards').innerHTML=list.map((d,i)=>`<article class="evidence-card"><div><div class="metric-top"><span>${escapeHTML(d.category.toUpperCase())}</span><span>${String(i+1).padStart(2,'0')}</span></div><div class="metric-val">${escapeHTML(d.display)}</div><div class="metric-name">${escapeHTML(d.label)}</div><div class="metric-date">${escapeHTML(d.geography)}<br>${escapeHTML(d.period)}</div></div><a href="#sources" class="metric-action" data-source="${escapeHTML(d.sourceId)}" title="${escapeHTML(d.note)}"><span>VIEW SOURCE & DEFINITION</span><span>↗</span></a></article>`).join('')||'<div class="placeholder">No verified records in this category.</div>';
 $('#pulse-cards').querySelectorAll('[data-source]').forEach(a=>a.addEventListener('click',ev=>{ev.preventDefault();showSources(a.dataset.source)}));
}
function renderSectors(active){
 const pick=$('#sector-picker');
 pick.innerHTML=stakeholders.map((s,i)=>`<button class="sector-option" aria-pressed="${s.id===active}" data-sector="${escapeHTML(s.id)}"><span class="sector-number">0${i+1}</span><span class="sector-name">${escapeHTML(s.name)}</span><span class="arrow">↗</span></button>`).join('');
 const s=stakeholders.find(x=>x.id===active)||stakeholders[0];
 if(!s)return;
 $('#sector-display').innerHTML=`<div class="sector-kicker">ECONOMIC EXPOSURE / ${escapeHTML(s.id.toUpperCase())}</div><h3>${escapeHTML(s.name)}</h3><div class="sector-rows"><div class="sector-col"><span class="c-label cost">↙ WHERE VALUE IS LOST</span><p>${escapeHTML(s.exposure)}</p></div><div class="sector-col"><span class="c-label benefit">↗ POTENTIAL VALUE CREATED</span><p>${escapeHTML(s.potential)}</p></div></div><div class="sector-measure"><b>WHAT WE WOULD ACTUALLY TRACK</b>${escapeHTML(s.measure)}</div><p class="sector-caveat">${escapeHTML(s.caveat)} <a href="#sources" data-source="${escapeHTML(s.sourceId)}">VIEW EVIDENCE ↗</a></p>`;
 pick.querySelectorAll('[data-sector]').forEach(b=>b.addEventListener('click',()=>renderSectors(b.dataset.sector)));
 $('#sector-display [data-source]')?.addEventListener('click',e=>{e.preventDefault();showSources(e.currentTarget.dataset.source)});
}
function renderFunding(){
 $('#funding-cards').innerHTML=funding.map(f=>`<article class="funding-item"><header><h3>${escapeHTML(f.name)}</h3><span class="stage">${escapeHTML(f.stage)}</span></header><div class="funding-amount">${escapeHTML(f.amountText)}</div><dl><dt>STATUS DATE</dt><dd>${escapeHTML(f.when)}</dd><dt>RECIPIENT</dt><dd>${escapeHTML(f.recipient)}</dd><dt>NEXT STEP</dt><dd>${escapeHTML(f.next)}</dd></dl><a href="#sources" data-source="${escapeHTML(f.sourceId)}">READ ORIGINAL RECORD ↗</a></article>`).join('');
 $('#funding-cards').querySelectorAll('a').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();showSources(a.dataset.source)}));
}
function updateSimulator(){
 const investment=Number($('#investment-range').value),capture=Number($('#capture-range').value);
 $('#investment-value').textContent=shortMoney(investment);
 $('#capture-value').textContent=`${capture}%`;
 // Hypothetical cost equivalence, not predicted number of shootings prevented or budget cash savings.
 const breakEven=investment/(652640.04*capture/100);
 $('#break-even-value').textContent=breakEven.toFixed(1);
}
const pathways={
 survivor:[['01','IMMEDIATE RESPONSE','Emergency services, trauma care and initial physical safety.'],['02','RECOVERY','Surgery, rehabilitation and support for longer-term injury.'],['03','FINANCIAL STRESS','Medical expenses, time off work, transport and possible housing disruption.'],['04','TRAUMA SUPPORT','Counseling, family support and help returning to everyday routines.'],['05','CONNECTION','Victim compensation, coordinated referrals and community services.']],
 family:[['01','IMMEDIATE SHOCK','Responders, police, medical examiner or hospital communication.'],['02','PRACTICAL NEEDS','Funeral planning, arrangements and potential assistance with costs.'],['03','FAMILY STABILITY','Caregiving changes, income disruptions and housing or food needs.'],['04','GRIEF & HEALING','Bereavement support, school support and long-term mental health services.'],['05','ACCESS TO HELP','Official guidance, victim compensation and community organizations.']]
};
function renderPath(name){
 $('#ripple-flow').innerHTML=pathways[name].map(x=>`<article class="ripple-node"><span class="step">${x[0]} / RIPPLE</span><h3>${x[1]}</h3><p>${x[2]}</p></article>`).join('');
 $$('.ripple-pill').forEach(b=>b.classList.toggle('chosen',b.dataset.path===name));
}
function renderSources(){
 $('#source-list').innerHTML=sources.map(s=>`<article class="source-card" id="src-${escapeHTML(s.id)}"><div class="source-meta">${escapeHTML(s.quality.toUpperCase())} / ${escapeHTML(s.date)}</div><h3>${escapeHTML(s.title)}</h3><p>${escapeHTML(s.publisher)} · ${escapeHTML(s.geography)}</p><a href="${escapeHTML(s.url)}" target="_blank" rel="noopener noreferrer">READ ORIGINAL SOURCE ↗</a></article>`).join('');
}
function message(body,who,linked=[]){
 const el=document.createElement('div');el.className='chat-msg '+who;el.textContent=body;
 if(linked.length){const links=document.createElement('div');links.className='source-links';linked.forEach(s=>{let a=document.createElement('a');a.href=s.url;a.target='_blank';a.rel='noopener noreferrer';a.textContent=s.name+' ↗';links.append(a)});el.append(links)}
 $('#chat-messages').append(el);$('#chat-messages').scrollTop=$('#chat-messages').scrollHeight;
}
let asking=false;
async function ask(q){
 q=String(q||'').trim();if(!q||asking)return;
 if(q.length>450){message('Please shorten your question to 450 characters.','bot');return;}
 message(q,'user');$('#chat-input').value='';asking=true;
 try{
 const resp=await fetch('/api/v1/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q})});if(!resp.ok)throw Error('Connection issue');const o=await resp.json();message(o.answer,'bot',o.sources||[]);
 }catch{message('The source guide is temporarily unavailable. Please use the source ledger below for direct access.','bot')}finally{asking=false;}
}
async function load(){
 try{
 const [a,b,c,d]=await Promise.all([fetch('/api/v1/evidence'),fetch('/api/v1/funding'),fetch('/api/v1/stakeholders'),fetch('/api/v1/resources')]);
 if(!a.ok||!b.ok||!c.ok||!d.ok)throw Error('API unavailable');
 const [ea,fu,st]=await Promise.all([a.json(),b.json(),c.json(),d.json()]);
 evidence=ea.statistics;sources=ea.sources;funding=fu.funding;stakeholders=st.stakeholders;
 renderEvidence();renderSectors(stakeholders[0].id);renderFunding();renderSources();
 }catch(err){if(window.ATL_SEED){const d=window.ATL_SEED;evidence=d.statistics;sources=d.sources;funding=d.funding;stakeholders=d.stakeholders;renderEvidence();renderSectors(stakeholders[0].id);renderFunding();renderSources();}else{$('#pulse-cards').innerHTML='<div class="placeholder">The evidence API is not available. Please open the source ledger.</div>'}}
}
$$('[role=tab]').forEach(t=>{
 t.addEventListener('click',()=>chooseTab(t.dataset.tab));
 t.addEventListener('keydown',e=>{const all=$$('[role=tab]');const i=all.indexOf(t);if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();const n=all[(i+(e.key==='ArrowRight'?1:-1)+all.length)%all.length];chooseTab(n.dataset.tab);n.focus()}});
});
$('#hero-explore').addEventListener('click',()=>chooseTab('pulse',true));
$('#hero-investment').addEventListener('click',()=>chooseTab('funding',true));
$('#pulse-filters').addEventListener('click',e=>{let el=e.target.closest('[data-filter]');if(!el)return;$$('[data-filter]').forEach(b=>b.classList.toggle('selected',b===el));renderEvidence(el.dataset.filter)});
$$('[data-source]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();showSources(e.currentTarget.dataset.source)}));
$('#sources-top').addEventListener('click',()=>showSources());
$('#open-sources').addEventListener('click',()=>showSources());
$('#view-method').addEventListener('click',()=>showSources());
$('#close-sources').addEventListener('click',()=>{$('#sources').hidden=true;$('.bottom-cta').scrollIntoView({behavior:'smooth',block:'start'})});
$$('.ripple-pill').forEach(b=>b.addEventListener('click',()=>renderPath(b.dataset.path)));
$$('.suggestions button').forEach(b=>b.addEventListener('click',()=>ask(b.dataset.q)));
$('#chat-form').addEventListener('submit',e=>{e.preventDefault();ask($('#chat-input').value)});
$('#investment-range').addEventListener('input',updateSimulator);$('#capture-range').addEventListener('input',updateSimulator);
renderPath('survivor');updateSimulator();
load();
let hash=location.hash.slice(1);if(['pulse','money','funding','ripple','assistant'].includes(hash))chooseTab(hash);
