'use strict';
const {spawn}=require('node:child_process'),assert=require('node:assert/strict'),path=require('node:path');
const cwd=__dirname,port=31890,root=`http://127.0.0.1:${port}`;
const srv=spawn(process.execPath,['-r',path.join(cwd,'test-mortality-mock.js'),'server.js'],{cwd,env:{...process.env,PORT:String(port)},stdio:['ignore','ignore','pipe']});
(async()=>{try{
 let ready=false;for(let i=0;i<80;i++){try{const r=await fetch(root+'/api/health');if(r.ok){ready=true;break}}catch{}await new Promise(r=>setTimeout(r,75))}assert(ready);
 let r=await fetch(root+'/api/v1/county-metrics?year=2024');assert.equal(r.status,200);let d=await r.json();
 assert.equal(d.sourceMode,'documented-examples-only');assert.equal(d.sourceAvailable,false);
 assert.equal(d.counties['13121'].firearmHomicides.deaths,181);
 assert.equal(d.counties['13121'].firearmHomicides.rate,16.8);
 assert.equal(d.counties['13121'].firearmDeaths,undefined);
 assert(!d.counties['13067']); // Never fabricate for other counties
 r=await fetch(root+'/api/v1/county-metrics?year=2022');assert.equal(r.status,200);d=await r.json();
 assert.equal(d.counties['13163'].firearmDeaths.deaths,10);
 r=await fetch(root+'/api/v1/county-history?county_fips=13121');assert.equal(r.status,200);d=await r.json();
 assert.equal(d.rows.find(x=>x.year===2024).firearmHomicides.deaths,181);
 r=await fetch(root+'/api/v1/county-injury-visits?year=2024');assert.equal(r.status,200);d=await r.json();
 assert.equal(d.counties['13121'].erVisitsNoAdmission,7);
 console.log('V4 SERVER: verified reference-data fallback, mortality years, partial count policy, injury path PASS');
}catch(e){console.error(e);process.exitCode=1}finally{srv.kill('SIGTERM')}})();
