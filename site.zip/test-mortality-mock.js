'use strict';
const original=globalThis.fetch;
globalThis.fetch=async function(url,opts){
 const u=new URL(String(url));
 if(u.hostname==='georgiacivicdata.org' && /\/(firearm_deaths|homicide_deaths)\/rows$/.test(u.pathname)){
  return {ok:false,status:503};
 }
 if(u.hostname==='georgiacivicdata.org' && u.pathname.endsWith('/er_visits_by_cause/rows')){
  return {ok:true,json:async()=>({data:[{year:2024,county_fips:'13121',cause:'accidental_shooting',demographic:'all',num_er_visits:7,er_visit_rate_per_100k:0.6}],pagination:{has_more:false}})};
 }
 return original(url,opts);
};
