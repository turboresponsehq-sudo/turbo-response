'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const evidence = require('./data/evidence.json');
const ROOT = path.join(__dirname, 'public');
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.ico':'image/x-icon'};
function send(res,status,body,ctype='application/json; charset=utf-8'){
 res.writeHead(status,{'Content-Type':ctype,'Cache-Control': ctype.includes('json')?'no-store':'public, max-age=3600','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; connect-src 'self'; img-src 'self' data:; font-src 'self'; style-src 'self'; script-src 'self'; base-uri 'self'; frame-ancestors 'none'; form-action 'none'"});res.end(body);
}
function guide(q){
 const s=String(q||'').trim().slice(0,600).toLowerCase();
 if(!s)return {answer:'Ask about the cost of violence, funding, a community resource, or how this evidence was collected.',ids:['nicjr','fulton2026']};
 if(/emergency|right now|in danger|someone (is )?(shot|bleeding)|911/.test(s))return{answer:'If someone is in immediate danger or has been shot, call 911 now. This prototype is not an emergency service and cannot contact responders.',ids:[]};
 if(/funeral|burial|lost|died|killed|victim|grief|counsel|therapy|medical/.test(s))return{answer:'Georgia’s Crime Victims Compensation Program may cover eligible medical, funeral and counseling expenses, subject to limits and application rules. For death investigation questions, Fulton County Medical Examiner publishes official guidance. These resources do not guarantee approval.',ids:['cjcc','fcme']};
 if(/fund|grant|million|500|budget|where (does|is).*money|spend/.test(s))return{answer:'Fulton County announced a commitment of at least $500,000 for 2027 violence intervention. Its budget is not finalized and recipients have not been selected in the cited announcement. NICJR’s 2024 study separately models long-term public costs of shootings; this is not cash already spent.',ids:['fulton2026','nicjr']};
 if(/business|job|property|economic|profit|workforce|retail|investment/.test(s))return{answer:'Urban Institute research in Minneapolis, Oakland and Washington, DC associated increases in neighborhood gun violence with weaker business growth. Those results cannot be turned into an Atlanta revenue forecast without local evidence.',ids:['urban','nicjr']};
 if(/age|teen|child|youth|map|neigh|where|count|how many|assault|robbery|shoot/.test(s))return{answer:'Official datasets measure different things: incidents, victims, medical visits, and death records. Georgia DPH provides a violent-death dashboard for Atlanta, but this prototype does not yet have a complete age-by-weapon incident dataset. Please use source-specific statistics and avoid adding overlapping counts.',ids:['gvdrs','fcme']};
 return {answer:'ATL IMPACT is an independent evidence demonstration. The public-cost model is from NICJR, the funding milestone from Fulton County, and available services from Georgia CJCC. Choose a source to inspect the original material.',ids:['nicjr','fulton2026','cjcc']};
}
const srv=http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://localhost');
 if(req.method==='GET'&&u.pathname==='/api/health')return send(res,200,JSON.stringify({ok:true,project:'ATL IMPACT',asOf:evidence.asOf}));
 if(req.method==='GET'&&u.pathname==='/api/v1/evidence'){
   const category=u.searchParams.get('category'),geo=u.searchParams.get('geography');
   const stats=evidence.statistics.filter(x=>(!category||category==='all'||x.category===category)&&(!geo||geo==='all'||x.geography.toLowerCase().includes(geo.toLowerCase())));
   return send(res,200,JSON.stringify({asOf:evidence.asOf,statistics:stats,sources:evidence.sources}));
 }
 if(req.method==='GET'&&u.pathname==='/api/v1/funding')return send(res,200,JSON.stringify({asOf:evidence.asOf,funding:evidence.funding}));
 if(req.method==='GET'&&u.pathname==='/api/v1/stakeholders')return send(res,200,JSON.stringify({stakeholders:evidence.stakeholders}));
 if(req.method==='GET'&&u.pathname==='/api/v1/resources')return send(res,200,JSON.stringify({resources:evidence.resources}));
 if(req.method==='POST'&&u.pathname==='/api/v1/ask'){
   if(!String(req.headers['content-type']||'').includes('application/json'))return send(res,415,JSON.stringify({error:'application/json required'}));
   let b='';for await(const c of req){b+=c;if(b.length>1500)break;}if(b.length>1500)return send(res,413,JSON.stringify({error:'Request too large'}));
   let obj;try{obj=JSON.parse(b)}catch{return send(res,400,JSON.stringify({error:'Bad JSON'}))}
   const g=guide(obj.question);return send(res,200,JSON.stringify({answer:g.answer,sources:evidence.sources.filter(x=>g.ids.includes(x.id)),kind:'guided-source-assistant',stored:false}));
 }
 if(req.method!=='GET')return send(res,405,'Method not allowed','text/plain; charset=utf-8');
 const wanted=path.posix.normalize(decodeURIComponent(u.pathname));
 let file=path.resolve(ROOT,'.'+wanted);
 if(!file.startsWith(ROOT+path.sep)&&file!==ROOT)return send(res,403,'Forbidden','text/plain; charset=utf-8');
 if(wanted==='/'||!path.extname(file))file=path.join(ROOT,'index.html');
 try { const st=fs.statSync(file);if(!st.isFile())throw Error('not file');return send(res,200,fs.readFileSync(file),MIME[path.extname(file)]||'application/octet-stream');}catch{return send(res,404,'Not found','text/plain; charset=utf-8')}
});
srv.listen(Number(process.env.PORT)||3000,'0.0.0.0');
