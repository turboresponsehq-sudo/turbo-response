'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const evidence = require('./data/evidence.json');
const ROOT = path.join(__dirname, 'public');
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.ico':'image/x-icon'};
function send(res,status,body,ctype='application/json; charset=utf-8'){
 res.writeHead(status,{'Content-Type':ctype,'Cache-Control': ctype.includes('json')?'no-store':'public, max-age=3600','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; connect-src 'self'; img-src 'self' data:; font-src 'self'; style-src 'self'; script-src 'self'; base-uri 'self'; frame-ancestors 'none'; form-action 'none'"});res.end(body);
}
function guide(q){
 const s=String(q||'').trim().slice(0,600).toLowerCase();
 if(!s)return {answer:'Ask about the cost of violence, funding, a community resource, or how this evidence was collected.',ids:['nicjr','fulton2026']};
 if(/emergency|right now|in danger|someone (is )?(shot|bleeding)|911/.test(s))return{answer:'If someone is in immediate danger or has been shot, call 911 now. This prototype is not an emergency service and cannot contact responders.',ids:[]};
 if(/funeral|burial|lost|died|killed|victim|grief|counsel|therapy|medical/.test(s))return{answer:'Georgia’s Crime Victims Compensation Program may cover eligible medical, funeral and counseling expenses, subject to limits and application rules. For death investigation questions, Fulton County Medical Examiner publishes official guidance. These resources do not guarantee approval.',ids:['cjcc','fcme']};
 if(/fund|grant|million|500|budget|where (does|is).*money|spend/.test(s))return{answer:'Fulton County announced a commitment of at least $500,000 for 2027 violence intervention. Its budget is not finalized and recipients have not been selected in the cited announcement. NICJR’s 2024 study separately models long-term public costs of shootings; this is not cash already spent.',ids:['fulton2026','nicjr']};
 if(/business|job|property|economic|profit|workforce|retail|investment/.test(s))return{answer:'Urban Institute research in Minneapolis, Oakland and Washington, DC associated increases in neighborhood gun violence with weaker business growth. Those results cannot be turned into an Atlanta revenue forecast without local evidence.',ids:['urban','nicjr']};
 if(/age|teen|child|youth|map|neigh|where|count|how many|assault|robbery|shoot/.test(s))return{answer:'Official datasets measure different things: incidents, victims, medical visits, and death records. Georgia DPH provides a violent-death dashboard for Atlanta, but this prototype does not yet have a complete age-by-weapon incident dataset. Please use source-specific statistics and avoid adding overlapping counts.',ids:['gvdrs','fcme']};
 return {answer:'ATL IMPACT is an independent evidence demonstration. The public-cost model is from NICJR, the funding milestone from Fulton County, and available services from Georgia CJCC. Choose a source to inspect the original material.',ids:['nicjr','fulton2026','cjcc']};
}
// The map retrieves public Census geography and caches the result in memory. No incident data is requested here.
const GEO_SOURCE='https://tigerweb.geo.census.gov/arcgis/rest/services/TIGERweb/tigerWMS_Current/MapServer';
const mapCache={};
async function censusGeometry(kind){
 if(mapCache[kind])return mapCache[kind];
 const layer=kind==='counties'?82:58, fields=kind==='counties'?'GEOID,STATE,BASENAME,NAME':'GEOID,STATE,SLDL,BASENAME,NAME';
 const q=new URLSearchParams({where:"STATE = '13'",outFields:fields,returnGeometry:'true',outSR:'4326',geometryPrecision:'4',f:'geojson',resultRecordCount:'250'});
 const response=await fetch(`${GEO_SOURCE}/${layer}/query?${q}`,{signal:AbortSignal.timeout(8000),headers:{'Accept':'application/geo+json,application/json'}});
 if(!response.ok)throw Error('Census status '+response.status);
 const body=await response.text();if(body.length>16_000_000)throw Error('Boundary data exceeds configured limit');
 const data=JSON.parse(body);const expected=kind==='counties'?159:180;
 if(!Array.isArray(data.features)||data.features.length!==expected)throw Error('Boundary record count mismatch: '+data.features?.length);
 for(const f of data.features){if(!f.geometry||String(f.properties?.STATE)!=='13')throw Error('Invalid Georgia geometry')}
 data.metadata={publisher:'U.S. Census Bureau TIGERweb',vintage:'2026',kind,source:`${GEO_SOURCE}/${layer}`,verifiedCount:expected};mapCache[kind]=data;return data;
}
// Historical county mortality: CDC MIOV data normalized and served by Georgia Civic Data.
// The service uses public, read-only, no-key requests and a short memory cache;
// missing/suppressed figures are preserved as null, never imputed.
const PUBLIC_HEALTH_API='https://georgiacivicdata.org/api/v1/datasets';
const HEALTH_VINTAGE='2019–2024 final annual CDC MIOV data (county of residence)';
const mortalityCache=new Map(),mortalityPending=new Map(),manualRecheckTimes=new Map();
function cleanedMortality(row){
 if(!row||!/^13\d{3}$/.test(String(row.county_fips||'')))return null;
 const n=row.num_deaths;
 const rate=row.death_rate_per_100k;
 return {year:Number(row.year),county_fips:String(row.county_fips),
  deaths:n===null||n===undefined?null:Number(n),
  rate:rate===null||rate===undefined?null:Number(rate),
  modeled:row.rate_modeled===true||row.rate_modeled==='true',
  lower:row.death_rate_per_100k_ci_lower==null?null:Number(row.death_rate_per_100k_ci_lower),
  upper:row.death_rate_per_100k_ci_upper==null?null:Number(row.death_rate_per_100k_ci_upper)};
}
async function loadMioV(dataset,params){
 const u=new URL(`${PUBLIC_HEALTH_API}/${dataset}/rows`);
 for(const [k,v] of Object.entries(params))u.searchParams.set(k,String(v));
 const r=await fetch(u,{signal:AbortSignal.timeout(11000),headers:{Accept:'application/json'}});
 if(!r.ok)throw Error(`GCD ${dataset} HTTP ${r.status}`);
 const json=await r.json();
 if(!Array.isArray(json.data))throw Error('Missing dataset rows');
 if(json.pagination?.has_more)throw Error('Data page incomplete');
 return {data:json.data.map(cleanedMortality).filter(Boolean),citation:json.meta?.citation||''};
}
// These small snapshots are independently supported by the provider's published
// reference documentation, not simulated statistics. They are intentionally sparse.
const documentedSamples = require('./data/documented-mortality.json');
function documentedYear(year){
 const counties={};
 for(const x of documentedSamples.rows.filter(r=>r.year===year)){
  (counties[x.county_fips]||={})[x.metric]={
   year,county_fips:x.county_fips,deaths:x.deaths,rate:x.rate,
   modeled:false,lower:null,upper:null,provenance:'provider-documentation'
  };
 }
 return counties;
}
function mergeDocumented(target,year){
 const samples=documentedYear(year);
 for(const [fips,obj] of Object.entries(samples)){
  const current=target[fips]||={};
  for(const [metric,row] of Object.entries(obj))if(!current[metric])current[metric]=row;
 }
 return target;
}
async function mortalityForYear(year){
 const key='year'+year,now=Date.now();const cached=mortalityCache.get(key);
 if(cached&&cached.expires>now)return cached.value;
 if(mortalityPending.has(key))return mortalityPending.get(key);
 const task=(async()=>{
   const p={year,detail:'counties',limit:500};
   // Isolate the two upstream datasets: a failure in one must not discard the other.
   const results=await Promise.allSettled([
     loadMioV('firearm_deaths',p),loadMioV('homicide_deaths',{...p,method:'firearm'})
   ]);
   const fields=['firearmDeaths','firearmHomicides'],counties={};
   let available=0,issues=[];
   results.forEach((r,i)=>{
     if(r.status==='fulfilled'&&r.value.data.length>=120){
       available++;
       for(const row of r.value.data)(counties[row.county_fips]||={})[fields[i]]=row;
     }else{
       const reason=r.status==='rejected'?r.reason.message:'incomplete geographic coverage';
       issues.push(fields[i]+': '+String(reason).slice(0,120));
     }
   });
   mergeDocumented(counties,year);
   const mode=available===2?'source-data':available===1?'partial-source-data':'documented-examples-only';
   if(issues.length)console.warn('County mortality source issue: '+issues.join('; '));
   const value={year,asOf:new Date().toISOString(),vintage:HEALTH_VINTAGE,
     source:'CDC MIOV via Georgia Civic Data',countyOf:'decedent residence, not location of incident',
     sourceMode:mode,sourceAvailable:available>0,sourceIssues:issues,
     note:mode==='documented-examples-only'?'Live county data temporarily unavailable. Only a few independently documented examples are displayed; all others remain unavailable.':'Published county records; missing values are never treated as zero.',
     sourceLinks:['https://georgiacivicdata.org/api/datasets/health/firearm_deaths','https://georgiacivicdata.org/api/datasets/health/homicide_deaths'],counties};
   // Recheck a failed source relatively soon; do not lock in unavailable data for hours.
   mortalityCache.set(key,{expires:Date.now()+(available===2?6*3600*1000:5*60*1000),value});return value;
 })();mortalityPending.set(key,task);
 try{return await task}finally{mortalityPending.delete(key)}
}
async function mortalityHistory(fips){
 const key='history'+fips,now=Date.now(),cached=mortalityCache.get(key);
 if(cached&&cached.expires>now)return cached.value;
 if(mortalityPending.has(key))return mortalityPending.get(key);
 const task=(async()=>{
  const p={county_fips:fips,year_min:2019,year_max:2024,detail:'counties',limit:100};
  const results=await Promise.allSettled([loadMioV('firearm_deaths',p),loadMioV('homicide_deaths',{...p,method:'firearm'})]);
  const all=results[0].status==='fulfilled'?results[0].value.data:[];
  const hom=results[1].status==='fulfilled'?results[1].value.data:[];
  if(results[0].status==='rejected'||results[1].status==='rejected')console.warn('Historical county feed partial: '+fips);
  const rows=[];
  for(let year=2019;year<=2024;year++){
   const known=documentedYear(year)[fips]||{};
   rows.push({year,firearmDeaths:all.find(x=>x.year===year)||known.firearmDeaths||null,
    firearmHomicides:hom.find(x=>x.year===year)||known.firearmHomicides||null});
  }
  const value={county_fips:fips,asOf:new Date().toISOString(),vintage:HEALTH_VINTAGE,rows,
    sourceMode:results.every(x=>x.status==='fulfilled')?'source-data':'partial-documented-data'};
  mortalityCache.set(key,{expires:Date.now()+(results.every(x=>x.status==='fulfilled')?6*3600*1000:5*60*1000),value});return value;
 })();mortalityPending.set(key,task);
 try{return await task}finally{mortalityPending.delete(key)}
}
// Georgia DPH OASIS emergency-room injury proxy, via Georgia Civic Data.
// IMPORTANT: OASIS 'accidental_shooting' covers unintentional shooting ER visits
// *not* ending in admission. It is NOT all nonfatal gunshot injuries or all assaults.
// Published aggregate counts are visits, not distinct people; zero != unavailable.
const INJURY_DATA_SOURCE='https://georgiacivicdata.org/api/datasets/health/er_visits_by_cause';
const injuryCache=new Map(),injuryPending=new Map();
function validGeorgiaFips(v){return /^13\d{3}$/.test(String(v||''))}
function publicNumber(v){return v===null||v===undefined||v===''||!Number.isFinite(Number(v))?null:Number(v)}
function normalizeInjury(row){
 if(!row||!validGeorgiaFips(row.county_fips)||row.cause!=='accidental_shooting'||row.demographic!=='all')return null;
 const n=publicNumber(row.num_er_visits), rate=publicNumber(row.er_visit_rate_per_100k),adjusted=publicNumber(row.age_adjusted_er_visit_rate_per_100k);
 if(n!==null&&(!Number.isInteger(n)||n<0))return null;
 return {county_fips:String(row.county_fips),year:Number(row.year),erVisitsNoAdmission:n,crudeRate:rate,ageAdjustedRate:adjusted};
}
async function injuryVisitsYear(year){
 const key='injuries-'+year,now=Date.now(),cached=injuryCache.get(key);
 if(cached&&cached.expires>now)return cached.value;
 if(injuryPending.has(key))return injuryPending.get(key);
 const task=(async()=>{
  const u=new URL(`${PUBLIC_HEALTH_API}/er_visits_by_cause/rows`);
  for(const [k,v] of Object.entries({year,detail:'counties',cause:'accidental_shooting',demographic:'all',limit:500}))u.searchParams.set(k,String(v));
  const r=await fetch(u,{signal:AbortSignal.timeout(13000),headers:{Accept:'application/json'}});
  if(!r.ok)throw Error('OASIS proxy upstream HTTP '+r.status);
  const json=await r.json();if(!Array.isArray(json.data)||json.pagination?.has_more)throw Error('OASIS county rows incomplete');
  const counties={};
  for(const row of json.data){const x=normalizeInjury(row);if(x&&x.year===year)counties[x.county_fips]=x;}
  if(Object.keys(counties).length===0)throw Error('OASIS returned no matching Georgia county records');
  const value={year,asOf:new Date().toISOString(),status:'source-records',source:'Georgia DPH OASIS via Georgia Civic Data',metric:'Accidental-shooting emergency visits NOT ending in inpatient admission',
   definition:'Unintentional/accidental shootings only (W32–W34). Excludes firearm assaults, self-harm, and admitted hospital patients. Visits not unique injured people. County of patient residence.',
   isAllNonfatalInjuries:false,sourceLinks:[INJURY_DATA_SOURCE,'https://oasis.state.ga.us/dtt/er','https://dph.georgia.gov/faster-ga'],
   countyCount:Object.keys(counties).length,counties};
  injuryCache.set(key,{value,expires:Date.now()+6*3600*1000});return value;
 })();injuryPending.set(key,task);
 try{return await task}finally{injuryPending.delete(key)}
}
const srv=http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://localhost');
 // Remove ChatGPT referral tags from the visible URL while preserving unrelated query parameters.
 // This is a same-origin URL normalization, not an analytics or visitor-tracking feature.
 if(req.method==='GET'){
   let changed=false;
   for(const [key,val] of [...u.searchParams.entries()]){
     if(/chatgpt(?:\.com)?/i.test(val) && /^(utm_[a-z0-9_]+|ref|source)$/i.test(key)){
       u.searchParams.delete(key);changed=true;
     }
   }
   if(changed){
     const clean=u.pathname+(u.searchParams.size?'?'+u.searchParams.toString():'');
     res.writeHead(302,{'Location':clean,'Cache-Control':'no-store','Referrer-Policy':'no-referrer'});
     res.end();return;
   }
 }
 if(req.method==='GET'&&u.pathname==='/api/v1/map/counties'){
   try{return send(res,200,JSON.stringify(await censusGeometry('counties')))}catch(e){
    const fallback=JSON.parse(fs.readFileSync(path.join(ROOT,'georgia-counties-fallback.json'),'utf8'));
    fallback.metadata={...fallback.metadata,vintage:'legacy',note:'2026 Census fetch unavailable; fallback geography not validated for current legal boundaries',error:'current_2026_geography_unavailable'};
    return send(res,200,JSON.stringify(fallback));
   }
 }
 if(req.method==='GET'&&u.pathname==='/api/v1/map/districts'){
   try{return send(res,200,JSON.stringify(await censusGeometry('districts')))}catch(e){return send(res,503,JSON.stringify({error:'Official district boundaries not presently accessible; do not infer overlaps',source:`${GEO_SOURCE}/58`,status:'pending'}))}
 }
 if(req.method==='GET'&&u.pathname==='/api/v1/county-injury-visits'){
   const year=Number(u.searchParams.get('year'));
   if(!Number.isInteger(year)||year<2019||year>2025)
    return send(res,400,JSON.stringify({error:'Available OASIS injury-care years in this prototype: 2019–2025; 2026 not published here.'}));
   try{return send(res,200,JSON.stringify(await injuryVisitsYear(year)))}
   catch(e){console.warn('County ER injury visits unavailable',e.message);return send(res,503,JSON.stringify({status:'unavailable',year,source:'Georgia DPH OASIS via Georgia Civic Data',error:'Injury-care records temporarily unavailable. No estimates substituted.'}))}
 }
 if(req.method==='GET'&&u.pathname==='/api/v1/county-metrics'){
   const year=Number(u.searchParams.get('year'));
   if(u.searchParams.get('refresh')==='1' && Number.isInteger(year)){
     const last=manualRecheckTimes.get(year)||0;
     if(Date.now()-last>60000){manualRecheckTimes.set(year,Date.now());mortalityCache.delete('year'+year)}
   }
   if(!Number.isInteger(year)||year<2019||year>2024)
    return send(res,400,JSON.stringify({error:'Only final annual CDC years 2019–2024 are available. No 2025/2026 estimates are supplied.'}));
   try{return send(res,200,JSON.stringify(await mortalityForYear(year)))}
   catch(e){console.warn('County metrics unavailable',e.message);return send(res,503,JSON.stringify({status:'unavailable',year,source:'CDC MIOV via Georgia Civic Data',error:'Upstream source temporarily unavailable. No values fabricated.'}))}
 }
 if(req.method==='GET'&&u.pathname==='/api/v1/county-history'){
   const fips=u.searchParams.get('county_fips')||'';
   if(!/^13\d{3}$/.test(fips))return send(res,400,JSON.stringify({error:'Valid 5-digit Georgia county FIPS required'}));
   try{return send(res,200,JSON.stringify(await mortalityHistory(fips)))}
   catch(e){console.warn('County history unavailable',e.message);return send(res,503,JSON.stringify({status:'unavailable',error:'Historical source temporarily unavailable. No values fabricated.'}))}
 }
 if(req.method==='GET'&&u.pathname==='/api/health')return send(res,200,JSON.stringify({ok:true,project:'ATL IMPACT',asOf:evidence.asOf,countyApi:'source-backed with verified-documentation fallback'}));
 if(req.method==='GET'&&u.pathname==='/api/v1/evidence'){
   const category=u.searchParams.get('category'),geo=u.searchParams.get('geography');
   const stats=evidence.statistics.filter(x=>(!category||category==='all'||x.category===category)&&(!geo||geo==='all'||x.geography.toLowerCase().includes(geo.toLowerCase())));
   return send(res,200,JSON.stringify({asOf:evidence.asOf,statistics:stats,sources:evidence.sources}));
 }
 if(req.method==='GET'&&u.pathname==='/api/v1/funding')return send(res,200,JSON.stringify({asOf:evidence.asOf,funding:evidence.funding}));
 if(req.method==='GET'&&u.pathname==='/api/v1/stakeholders')return send(res,200,JSON.stringify({stakeholders:evidence.stakeholders}));
 if(req.method==='GET'&&u.pathname==='/api/v1/resources')return send(res,200,JSON.stringify({resources:evidence.resources}));
 if(req.method==='POST'&&u.pathname==='/api/v1/ask'){
   if(!String(req.headers['content-type']||'').includes('application/json'))return send(res,415,JSON.stringify({error:'application/json required'}));
   let b='';for await(const c of req){b+=c;if(b.length>1500)break;}if(b.length>1500)return send(res,413,JSON.stringify({error:'Request too large'}));
   let obj;try{obj=JSON.parse(b)}catch{return send(res,400,JSON.stringify({error:'Bad JSON'}))}
   const g=guide(obj.question);return send(res,200,JSON.stringify({answer:g.answer,sources:evidence.sources.filter(x=>g.ids.includes(x.id)),kind:'guided-source-assistant',stored:false}));
 }
 if(req.method!=='GET')return send(res,405,'Method not allowed','text/plain; charset=utf-8');
 const wanted=path.posix.normalize(decodeURIComponent(u.pathname));
 let file=path.resolve(ROOT,'.'+wanted);
 if(!file.startsWith(ROOT+path.sep)&&file!==ROOT)return send(res,403,'Forbidden','text/plain; charset=utf-8');
 if(wanted==='/'||!path.extname(file))file=path.join(ROOT,'index.html');
 try { const st=fs.statSync(file);if(!st.isFile())throw Error('not file');return send(res,200,fs.readFileSync(file),MIME[path.extname(file)]||'application/octet-stream');}catch{return send(res,404,'Not found','text/plain; charset=utf-8')}
});
srv.listen(Number(process.env.PORT)||3000,'0.0.0.0');
