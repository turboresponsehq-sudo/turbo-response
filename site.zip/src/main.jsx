import React from 'react';
import { createRoot } from 'react-dom/client';
import './resources.js';
import './App.js';
import './tailwind.css';
import './styles.css';
const App = window.createCampaignApp(React);
createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);
