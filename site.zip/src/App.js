/* Kenn Collier Sr. — informational website prototype.
   All campaign facts reflect the candidate's published website and externally identified election information.
   No backend, donor capture, contact storage, tracking or form submission. */
(function (root) {
  root.createCampaignApp = function (React) {
    const h = React.createElement;
    const {useState, useEffect} = React;
    const site = 'https://www.kenncollier.com';
    const instagram = 'https://www.instagram.com/kenncollier/';
    const resourceGroups = root.kennResourceData || [];
    const policies = resourceGroups.map((p,index)=>({
      ...p, id: String(index+1).padStart(2,'0'),
      path: '#priority-'+p.slug
    }));
    const nav = [
      ['Home','#home'],['Priorities','#priorities'],['Community Resources','#community-resources'],
      ['Meet Kenn','#meet'],['News & Media','#media'],['Events','#events'],['Contact','#contact']
    ];
    const isActive = (path) => window.location.hash === path;
    const Arrow = ({diagonal=false}) => h('span',{className:'arrow-icon','aria-hidden':'true'}, diagonal?'↗':'→');
    const External = ({href,children,className='',label})=>h('a',{href,target:'_blank',rel:'noopener noreferrer',className,'aria-label':label},children);
    const Eyebrow = ({children})=>h('span',{className:'eyebrow'},h('span',{className:'eyebrow-rule'}),children);
    const Mark = ({onClick}) => h('a',{className:'brand',href:'#home',onClick,'aria-label':'Kenn Collier campaign prototype — Home'},
      h('span',{className:'brand-tag'},'GEORGIA HOUSE / DISTRICT 62'),
      h('span',{className:'brand-word'},'KENN',h('span',{className:'brand-dot'},'.')),
      h('span',{className:'brand-word brand-word-two'},'COLLIER'),
      h('span',{className:'brand-bottom'},'SR.  /  2026'));
    function TopBar(){return h('div',{className:'topbar'},h('span',{},'CAMPAIGN INFORMATIONAL PROTOTYPE'),h('span',{className:'topbar-right'},'GEORGIA STATE HOUSE  •  DISTRICT 62'));}
    function Header(){const [open,setOpen] = useState(false);
      useEffect(()=>{function onKey(ev){if(ev.key==='Escape')setOpen(false)}
        window.addEventListener('keydown',onKey);return ()=>window.removeEventListener('keydown',onKey)},[]);
      return h(React.Fragment,null,
        h(TopBar),
        h('header',{className:'header'},
          h(Mark,{onClick:()=>setOpen(false)}),
          h('nav',{className:'desktop-nav','aria-label':'Primary navigation'},nav.map(([name,url])=>h('a',{href:url,key:name,'aria-current':isActive(url)?'page':undefined},name))),
          h(External,{href:site+'/donate',className:'nav-donate',label:'Open Kenn Collier’s existing donation page'},'DONATE ',h(Arrow,{diagonal:true})),
          h('button',{className:'menu-toggle',type:'button','aria-label':open?'Close navigation':'Open navigation','aria-expanded':open,'aria-controls':'mobile-nav',onKeyDown:(e)=>{if(e.key==='Escape')setOpen(false)},onClick:()=>setOpen(!open)},h('span',{}),h('span',{}),h('span',{}))
        ),
        h('nav',{id:'mobile-nav',className:'mobile-menu'+(open?' is-open':''),'aria-label':'Mobile navigation',inert:!open?true:undefined,onKeyDown:(e)=>{if(e.key==='Escape')setOpen(false)}},
          nav.map(([name,url],i)=>h('a',{key:name,href:url,'aria-current':isActive(url)?'page':undefined,onClick:()=>setOpen(false)},h('small',{},String(i+1).padStart(2,'0')),name,h(Arrow,{diagonal:true}))),
          h(External,{href:site+'/donate',className:'mobile-donate'},'DONATION INFORMATION ',h(Arrow,{diagonal:true}))
        )
      );
    }
    function Hero(){return h('section',{id:'home',className:'hero'},
      h('div',{className:'hero-art','aria-hidden':'true'},h('span',{className:'circle circle-a'}),h('span',{className:'circle circle-b'}),h('div',{className:'hero-grid'})),
      h('div',{className:'hero-content'},
        h('div',{className:'hero-topnote'},h('span',{className:'live-dot'}),'2026 GEORGIA GENERAL ELECTION  /  NOV 03'),
        h('div',{className:'hero-kicker'},'KENN COLLIER SR.',h('span',{},' / DISTRICT 62')),
        h('h1',{},h('span',{},'LEADERSHIP FOR A'),h('strong',{},'SAFER,'),h('em',{},'STRONGER'),h('strong',{},'GEORGIA',h('span',{className:'orange-period'},'.'))),
        h('p',{className:'hero-intro'},'Kenn Collier Sr. is the Democratic nominee for Georgia House District 62. Explore his background, published priorities, and public campaign information.'),
        h('div',{className:'hero-actions'},h('a',{className:'btn btn-orange',href:'#priorities'},'EXPLORE PRIORITIES ',h(Arrow,{})),h('a',{className:'btn btn-outline',href:'#meet'},'MEET KENN ',h(Arrow,{}))),
        h('div',{className:'hero-foot'},h('span',{},'SOUTH ATLANTA'),h('span',{},'EAST POINT'),h('span',{},'COLLEGE PARK'))
      ),
      h('div',{className:'hero-person'},
        h('div',{className:'portrait-halo','aria-hidden':'true'}),
        h('div',{className:'portrait-frame'},h('picture',{},h('source',{media:'(max-width:700px)',srcSet:'/assets/official-campaign-poster.jpg'}),h('img',{src:'/assets/kenn-reference-portrait.jpg',alt:'Kenn Collier in his official campaign graphic, used as an unmodified reference image'}))),
        h('div',{className:'portrait-caption'},h('span',{},'OFFICIAL CAMPAIGN IMAGE'),h('span',{},'REFERENCE COPY / REPLACE WITH HI-RES ORIGINAL')),
        h('div',{className:'vertical-caption','aria-hidden':'true'},'62  /  GEORGIA STATE HOUSE')
      ),
      h('a',{href:'#meet',className:'hero-scroll','aria-label':'Go to Meet Kenn page'},'MEET KENN ',h('span',{},'↓'))
    );}
    function Ticker(){return h('div',{className:'ticker','aria-label':'Site themes'},h('div',{className:'ticker-inner'},
      ['COMMUNITY','OPPORTUNITY','ACCOUNTABILITY','DISTRICT 62','COMMUNITY','OPPORTUNITY','ACCOUNTABILITY','DISTRICT 62'].map((x,i)=>h('span',{key:i},x,h('span',{className:'ticker-star'},'✳')))));
    }
    function Meet(){return h('section',{id:'meet',className:'meet-section section-pad'},
      h('div',{className:'section-shell meet-grid'},
        h('div',{className:'meet-image-col'},
          h('div',{className:'photo-panel'},h('img',{src:'/assets/official-campaign-poster.jpg',alt:'Official Kenn Collier State House District 62 campaign graphic, shown in supplied campaign reference'})),
          h('div',{className:'photo-badge'},'01 / INTRODUCTION'),
          h('div',{className:'meet-side-stamp'},'FROM THE COMMUNITY · FOR THE COMMUNITY')
        ),
        h('div',{className:'meet-content'},h(Eyebrow,{},'MEET KENN'),h('h1',{className:'section-title'},'A STORY ROOTED',h('br',{}),'IN ',h('span',{className:'text-green'},'SOUTH ATLANTA.')),
          h('p',{className:'lead'},'Entrepreneur. Nonprofit leader. Father. Community advocate.'),
          h('p',{},'Kenn Collier was born and raised in South Atlanta and has worked across College Park and East Point. His published biography describes years of work with families, young people, and neighborhood leaders.'),
          h('p',{},'His stated areas of focus include violence prevention, youth development, community stability and access to economic opportunity.'),
          h('div',{className:'bio-facts'},h('div',{},h('strong',{},'SOUTH ATLANTA'),h('small',{},'ROOTS')),h('div',{},h('strong',{},'DISTRICT 62'),h('small',{},'2026 NOMINEE')),h('div',{},h('strong',{},'COMMUNITY'),h('small',{},'SERVICE FOCUS'))),
          h(External,{href:site+'/about',className:'text-link'},'READ VERIFIED CAMPAIGN BIOGRAPHY ',h(Arrow,{diagonal:true}))
        )
      )
    );}
    function PolicyCards({items=policies}){return h('div',{className:'policy-grid'},items.map((p,i)=>h('article',{key:p.id,className:'policy-card'},
      h('a',{href:p.path,className:'policy-click','aria-label':'Explore '+p.name},
        h('div',{className:'policy-top'},h('span',{},p.id+' / '+p.label),h('span',{className:'policy-plus','aria-hidden':'true'},'↗')),
        h('div',{className:'policy-mark','aria-hidden':'true'},['↗','◇','◎','▤','⌂','✳'][Number(p.id)-1]),
        h('h3',{},p.name),h('p',{},p.short),
        h('span',{className:'policy-read'},'VIEW PRIORITY & RESOURCES ',h(Arrow,{}))
      )
    )));}
    // One interactive priority directory: a category appears once, never duplicated
    // as a giant six-card grid followed by a second six-section list.
    function PriorityHub(){
      const fromHash=()=>{
        const slug=(window.location.hash||'').replace('#priority-','');
        return policies.some(p=>p.slug===slug)?slug:policies[0].slug;
      };
      const [selected,setSelected]=useState(fromHash);
      useEffect(()=>{
        const onHash=()=>{if(window.location.hash.startsWith('#priority-'))setSelected(fromHash());};
        window.addEventListener('hashchange',onHash);
        return ()=>window.removeEventListener('hashchange',onHash);
      },[]);
      const active=policies.find(p=>p.slug===selected)||policies[0];
      function choose(p){
        setSelected(p.slug);
        window.history.replaceState(null,'','#priority-'+p.slug);
        window.requestAnimationFrame(()=>document.getElementById('community-resources')?.scrollIntoView({behavior:'smooth',block:'start'}));
      }
      return h('section',{id:'priorities',className:'priority-hub section-pad'},h('div',{className:'section-shell'},
        h(Eyebrow,{},'COMMUNITY / SIX AREAS OF FOCUS'),
        h('div',{className:'priority-hub-header'},
          h('h2',{className:'section-title title-white'},'SIX PRIORITIES.',h('br',{}),h('span',{className:'title-orange'},'REAL RESOURCES.')),
          h('p',{},'Choose an area to find organizations offering services and support. No account needed.')
        ),
        h('div',{className:'priority-switcher',role:'group','aria-label':'Choose a community priority'},
          policies.map(p=>h('button',{type:'button',key:p.id,id:'priority-'+p.slug, className:'priority-choice'+(p.slug===selected?' selected':''), 'aria-pressed':p.slug===selected, onClick:()=>choose(p)},
            h('span',{className:'choice-number'},p.id),
            h('span',{className:'choice-title'},p.name),
            h('span',{className:'choice-arrow','aria-hidden':'true'},p.slug===selected?'−':'↗')
          ))
        ),
        h('div',{className:'priority-result',id:'community-resources',role:'region','aria-label':'Organizations related to '+active.name},
          h('div',{className:'priority-result-head'},
            h('div',{},h('span',{className:'resource-category-top'},active.id+' / '+active.label),h('h3',{},active.name)),
            h('p',{},active.short)
          ),
          h('div',{className:'resource-card-grid'},active.resources.map(entry=>h(ResourceCard,{entry,key:entry.name}))),
          h('p',{className:'resource-disclaimer'},'Resources are independent third-party organizations, not campaign partners. Everyone can use these links regardless of political affiliation.'),
          h(External,{href:site+'/priorities',className:'compact-official-link'},'READ KENN’S PUBLISHED PRIORITIES ',h(Arrow,{diagonal:true}))
        )
      ));
    }
    function ResourceCard({entry}){return h('article',{className:'resource-card'},
      h('h3',{},entry.name),
      h('p',{},entry.description),
      h(External,{href:entry.url,className:'btn btn-orange resource-visit',label:'Visit '+entry.name+' website (opens in a new tab)'},'VISIT WEBSITE ',h(Arrow,{diagonal:true}))
    );}
    function ResourceDirectory(){return h('section',{id:'community-resources',className:'resources-section section-pad'},h('div',{className:'section-shell'},
      h(Eyebrow,{},'COMMUNITY RESOURCE DIRECTORY / SIX PRIORITIES'),
      h('h2',{className:'section-title'},'FIND ',h('span',{className:'text-green'},'REAL RESOURCES.')),
      h('p',{className:'resource-lead'},'Select a priority above, or browse all six areas below. Each organization links directly to its own website.'),
      h('p',{className:'resource-disclaimer'},'These are independent third-party organizations, not campaign programs or official partners. Resources are available regardless of political affiliation or support.'),
      h('div',{className:'resource-priority-list'},policies.map(p=>h('section',{id:'priority-'+p.slug,className:'resource-priority',key:p.id},
        h('div',{className:'resource-priority-heading'},
          h('span',{className:'resource-category-top'},p.id+' / '+p.label),
          h('h3',{},p.name),h('p',{},p.short)
        ),
        h('div',{className:'resource-card-grid'},p.resources.map(entry=>h(ResourceCard,{entry,key:entry.name})))
      )))
    ));}
    function PriorityDetail({policy}){return h(React.Fragment,null,
      h('section',{className:'priority-detail-section section-pad'},h('div',{className:'section-shell'},
        h('a',{href:'#priorities',className:'crumb-link'},'← ALL PRIORITIES'),
        h(Eyebrow,{},policy.id+' / '+policy.label),
        h('h1',{className:'section-title title-white'},policy.name),
        h('p',{className:'priority-detail-summary'},policy.detail),
        h(External,{href:site+'/priorities',className:'text-link'},'VIEW PUBLISHED CAMPAIGN PRIORITIES ',h(Arrow,{diagonal:true}))
      )),
      h('section',{className:'resources-section section-pad'},h('div',{className:'section-shell'},
        h(Eyebrow,{},'INDEPENDENT ORGANIZATIONS'),
        h('h2',{className:'section-title'},'COMMUNITY ',h('span',{className:'text-green'},'RESOURCES.')),
        h('p',{className:'resource-disclaimer'},'Listed organizations operate independently of the campaign; these links are available to everyone, regardless of political affiliation.'),
        h('div',{className:'resource-card-grid'},policy.resources.map(entry=>h(ResourceCard,{entry,key:entry.name}))),
        h('div',{className:'related-links'},h('a',{href:'#community-resources',className:'text-link'},'ALL COMMUNITY RESOURCES ',h(Arrow,{})),h('a',{href:'#priorities',className:'text-link'},'SIX PRIORITIES ',h(Arrow,{})))
      ))
    );}
    function Community(){return h('section',{id:'community',className:'community-section section-pad'},h('div',{className:'section-shell'},
      h('div',{className:'community-intro'},h('div',{},h(Eyebrow,{},'THE DISTRICT / OUR COMMUNITIES'),h('h2',{className:'section-title'},'THE PEOPLE.',h('br',{}),h('span',{className:'text-green'},'THE PLACES.'))),h('p',{},'The campaign identifies South Atlanta, East Point, and College Park among the communities central to its work. This area is reserved for approved documentary photographs and community stories.')),
      h('div',{className:'community-cards'},
        ['SOUTH ATLANTA','EAST POINT','COLLEGE PARK'].map((place,i)=>h('article',{key:place,className:'community-card community-'+i},
          h('div',{className:'community-visual','aria-label':'Photograph placeholder for '+place},h('span',{className:'community-index'},'0'+(i+1)),h('div',{className:'community-rings','aria-hidden':'true'}),h('div',{className:'pending-photo'},'APPROVED COMMUNITY PHOTO',h('small',{},'ASSET PENDING'))),
          h('div',{className:'community-card-footer'},h('h3',{},place),h('span',{},'DISTRICT STORY / COMING SOON'))
        ))
      ),
      h('div',{className:'community-quote'},h('span',{},'“'),h('p',{},'Leadership Before the Title. A Lifetime of Showing Up.'),h('small',{},'EXISTING CAMPAIGN MESSAGING · KENNCOLLIER.COM'))
    ));}
    function Media(){const [tab,setTab]=useState('all');const items=[
      {kind:'official',eyebrow:'OFFICIAL CAMPAIGN',title:'Kenn Collier on Instagram',sub:'View the current profile, reels, and publicly shared updates.',href:instagram,thumb:'ig'},
      {kind:'official',eyebrow:'OFFICIAL WEBSITE',title:'Meet Kenn: background & biography',sub:'Campaign-published biography and public information.',href:site+'/about',thumb:'poster'},
      {kind:'archive',eyebrow:'EVENT ARCHIVE / 2026',title:'Volunteer campaign launch',sub:'February 28, 2026 · Event archive and campaign materials.',href:'https://www.mobilize.us/mobilize/event/913055/',thumb:'event'}
    ];const shown=items.filter(item=>tab==='all'||item.kind===tab);
      return h('section',{id:'media',className:'media-section section-pad'},h('div',{className:'section-shell'},
        h('div',{className:'section-heading media-head'},h('div',{},h(Eyebrow,{},'THE STORY / AS TOLD PUBLICLY'),h('h1',{className:'section-title title-white'},'NEWS ',h('span',{className:'title-orange'},'& MEDIA.'))),h('p',{},'A curated entry point to authentic campaign pages, public posts, and an archived event. No unverified stories or media have been added.')),
        h('div',{className:'media-tabs',role:'group','aria-label':'Filter media'},[['all','ALL MEDIA'],['official','OFFICIAL CHANNELS'],['archive','ARCHIVE']].map(([v,label])=>h('button',{key:v,type:'button','aria-pressed':tab===v,className:tab===v?'selected':'',onClick:()=>setTab(v)},label))),
        h('div',{className:'media-grid'},shown.map((item,i)=>h('article',{className:'media-card',key:item.title},
          h('div',{className:'media-cover '+item.thumb},item.thumb==='poster'?h('img',{src:'/assets/official-campaign-poster.jpg',alt:'Kenn Collier official campaign graphic'}):item.thumb==='event'?h('img',{src:'/assets/archived-ride-event.jpg',alt:'Supplied screenshot of an archived campaign event graphic'}):h('div',{className:'ig-cover'},h('span',{},'@KENNCOLLIER'),h('span',{className:'reels-icon'},'▹'),h('small',{},'INSTAGRAM / REELS / CAMPAIGN UPDATES')),
            h('span',{className:'media-cover-overlay'},item.eyebrow)
          ),h('div',{className:'media-meta'},h('span',{},item.eyebrow),h('h3',{},item.title),h('p',{},item.sub),h(External,{href:item.href,className:'media-link'},'OPEN SOURCE ',h(Arrow,{diagonal:true})))
        ))),
        h('div',{className:'video-placeholder'},h('span',{className:'play-outline'},'▷'),h('div',{},h('strong',{},'VIDEO SHOWCASE / APPROVED EMBEDS'),h('p',{},'Space reserved for verified campaign video clips, reels, and captions. No autoplay or fabricated footage.')),h(External,{href:instagram},'VIEW INSTAGRAM ',h(Arrow,{diagonal:true})))
      ));}
    function Events(){return h('section',{id:'events',className:'events-section section-pad'},h('div',{className:'section-shell event-layout'},
      h('div',{},h(Eyebrow,{},'DATES / PUBLIC INFORMATION'),h('h1',{className:'section-title'},'EVENTS ',h('span',{className:'text-green'},'& DATES.')),h('p',{className:'event-lead'},'Upcoming campaign event details have not been independently verified for this prototype. The archive below reflects a published event.'),h(External,{href:site+'/volunteer',className:'text-link'},'VIEW LIVE CAMPAIGN EVENTS ',h(Arrow,{diagonal:true}))),
      h('div',{className:'event-stack'},
        h('article',{className:'event-row'},h('div',{className:'date-card'},h('strong',{},'NOV',h('br',{}),'03'),h('span',{},'2026')),h('div',{className:'event-description'},h('span',{className:'event-tag'},'PUBLIC ELECTION DATE'),h('h3',{},'Georgia General Election'),h('p',{},'Tuesday, November 3, 2026 · Georgia House District 62'),h(External,{href:'https://ballotpedia.org/Kenn_Collier'},'VERIFY ELECTION INFORMATION ',h(Arrow,{diagonal:true})))),
        h('article',{className:'event-row'},h('div',{className:'date-card muted-date'},h('strong',{},'FEB',h('br',{}),'28'),h('span',{},'2026')),h('div',{className:'event-description'},h('span',{className:'event-tag muted-tag'},'PAST / ARCHIVED'),h('h3',{},'Volunteer Campaign Launch'),h('p',{},'Published event listing · East Point, Georgia'),h(External,{href:'https://www.mobilize.us/mobilize/event/913055/'},'VIEW ARCHIVED EVENT ',h(Arrow,{diagonal:true})))),
        h('div',{className:'future-note'},h('strong',{},'UPCOMING CAMPAIGN EVENTS'),h('p',{},'No future campaign event has been confirmed for this demo. Check the official events page for changes.'))
      )
    ));}
    function Contact(){const [message,setMessage]=useState(null);const [form,setForm]=useState({name:'',email:'',topic:'General question',body:''});function change(k,v){setForm(old=>({...old,[k]:v}));setMessage(null)}function submit(e){e.preventDefault();setMessage('Demonstration complete. No message was sent, saved, or shared. Use the official campaign contact page for real inquiries.');setForm({name:'',email:'',topic:'General question',body:''});}
      return h('section',{id:'contact',className:'contact-section section-pad'},h('div',{className:'section-shell contact-layout'},
        h('div',{className:'contact-copy'},h(Eyebrow,{},'CONTACT / OFFICIAL CHANNELS'),h('h1',{className:'section-title title-white'},'GET IN ',h('span',{className:'title-orange'},'TOUCH.')),h('p',{},'This local form is for interface demonstration only. It does not collect, send, or store personal information.'),
          h('div',{className:'contact-method'},h('span',{},'CAMPAIGN OFFICE'),h('strong',{},'2947 Legion Way',h('br',{}),'East Point, GA 30344')),
          h('div',{className:'contact-method'},h('span',{},'PUBLIC CAMPAIGN EMAIL'),h(External,{href:'mailto:campaign@kenncollier.com'},'campaign@kenncollier.com')),
          h('div',{className:'contact-method'},h('span',{},'LIVE CONTACT'),h(External,{href:site+'/contact'},'kenncollier.com/contact ',h(Arrow,{diagonal:true})))
        ),
        h('form',{className:'contact-form',onSubmit:submit},
          h('div',{className:'demo-badge'},'DEMONSTRATION FORM  ·  NO DATA SENT'),
          h('div',{className:'form-two'},
            h('label',{},'FULL NAME ',h('span',{},'*'),h('input',{required:true,type:'text',autoComplete:'off',placeholder:'Your name',value:form.name,onChange:e=>change('name',e.target.value)})),
            h('label',{},'EMAIL ADDRESS ',h('span',{},'*'),h('input',{required:true,type:'email',autoComplete:'off',placeholder:'you@example.com',value:form.email,onChange:e=>change('email',e.target.value)}))
          ),
          h('label',{},'SUBJECT',h('select',{value:form.topic,onChange:e=>change('topic',e.target.value)},['General question','Community inquiry','Media inquiry','Events question'].map(x=>h('option',{key:x,value:x},x)))),
          h('label',{},'YOUR MESSAGE ',h('span',{},'*'),h('textarea',{required:true,rows:5,placeholder:'Write a demonstration message...',value:form.body,onChange:e=>change('body',e.target.value)})),
          h('button',{className:'btn btn-orange submit-btn',type:'submit'},'TEST DEMO FORM ',h(Arrow,{})),
          h('p',{className:'form-note'},'Do not enter sensitive information. Nothing is transmitted.'),
          message&&h('div',{className:'form-success',role:'status'},message)
        )
      ));}
    function HomePreviews(){return h(React.Fragment,null,
      h('section',{className:'meet-section section-pad'},h('div',{className:'section-shell home-meet-preview'},
        h('div',{className:'home-meet-photo'},h('img',{src:'/assets/official-campaign-poster.jpg',alt:'Official Kenn Collier campaign reference graphic'})),
        h('div',{},h(Eyebrow,{},'01 / MEET KENN'),h('h2',{className:'section-title'},'ROOTED IN ',h('span',{className:'text-green'},'SOUTH ATLANTA.')),
          h('p',{className:'home-preview-body'},'Kenn Collier Sr. describes a background in community service, youth development, and neighborhood safety.'),
          h('a',{href:'#meet',className:'text-link'},'EXPLORE HIS BIOGRAPHY ',h(Arrow,{})))
      )),
      h('section',{className:'priorities-section section-pad'},h('div',{className:'section-shell'},
        h(Eyebrow,{},'02 / ISSUES & RESOURCES'),
        h('h2',{className:'section-title title-white'},'EXPLORE THE ',h('span',{className:'title-orange'},'PRIORITIES.')),
        h(PolicyCards,{items:policies.slice(0,3)}),
        h('div',{className:'home-quick-actions'},h('a',{href:'#priorities',className:'btn btn-orange'},'ALL SIX PRIORITIES ',h(Arrow,{})),h('a',{href:'#community-resources',className:'btn btn-outline'},'COMMUNITY RESOURCES ',h(Arrow,{})))
      ))
    );}
    function NotFound(){return h('section',{className:'resources-section section-pad'},h('div',{className:'section-shell'},h(Eyebrow,{},'PAGE NOT FOUND'),h('h1',{className:'section-title'},'PAGE ',h('span',{className:'text-green'},'UNAVAILABLE.')),h('a',{href:'#home',className:'btn btn-orange'},'RETURN HOME ',h(Arrow,{}))));}
    function Footer(){return h('footer',{className:'footer'},h('div',{className:'section-shell'},
      h('div',{className:'footer-main'},h('div',{},h('div',{className:'footer-logo'},'KENN',h('span',{},'.'),' COLLIER'),h('p',{},'Georgia House District 62 · 2026 Campaign Information')),h('div',{className:'footer-links'},
        h('a',{href:'#meet'},'Meet Kenn'),h('a',{href:'#priorities'},'Priorities'),h('a',{href:'#community-resources'},'Resources'),h('a',{href:'#media'},'News & Media'),h('a',{href:'#events'},'Events'),h('a',{href:'#contact'},'Contact'),h(External,{href:instagram},'Instagram'),h(External,{href:site+'/donate'},'Donation Page'))),
      h('div',{className:'footer-end'},h('span',{},'INDEPENDENT INFORMATIONAL PROTOTYPE'),h('span',{},'DEMONSTRATION ONLY · NO DATA CAPTURE')),
      h('p',{className:'footer-source'},'Candidate information reflects published campaign materials. The community directory links to independent third parties; these are not campaign partnerships. Image references are supplied campaign screenshots pending approved high-resolution originals.')
    ));}
    // Compact secondary information: intentionally keeps resources prominent.
    function CompactMeet(){return h('section',{id:'meet',className:'compact-meet section-pad'},h('div',{className:'section-shell compact-two'},
      h('div',{},h(Eyebrow,{},'MEET KENN'),h('h2',{className:'section-title'},'ROOTED IN ',h('span',{className:'text-green'},'SOUTH ATLANTA.'))),
      h('div',{},h('p',{},'Kenn Collier Sr. describes a background in community service, youth development, and neighborhood advocacy.'),
        h(External,{href:site+'/about',className:'compact-official-link'},'READ HIS OFFICIAL BIOGRAPHY ',h(Arrow,{diagonal:true})))
    ));}
    function CompactMedia(){return h('section',{id:'media',className:'compact-media section-pad'},h('div',{className:'section-shell compact-two'},
      h('div',{},h(Eyebrow,{},'OFFICIAL CHANNELS'),h('h2',{className:'section-title title-white'},'NEWS ',h('span',{className:'title-orange'},'& MEDIA.'))),
      h('div',{className:'compact-links'},h(External,{href:instagram},'INSTAGRAM UPDATES ',h(Arrow,{diagonal:true})),h(External,{href:site},'OFFICIAL WEBSITE ',h(Arrow,{diagonal:true})))
    ));}
    function CompactEvents(){return h('section',{id:'events',className:'compact-events section-pad'},h('div',{className:'section-shell compact-two'},
      h('div',{},h(Eyebrow,{},'CAMPAIGN INFORMATION'),h('h2',{className:'section-title'},'EVENTS ',h('span',{className:'text-green'},'& DATES.'))),
      h('div',{},h('p',{},'For current events and verified campaign information, use the official site.'),h(External,{href:site+'/volunteer',className:'compact-official-link'},'VIEW CAMPAIGN EVENTS ',h(Arrow,{diagonal:true})))
    ));}
    function CompactContact(){const [expanded,setExpanded]=useState(false);const [question,setQuestion]=useState('');const [submitted,setSubmitted]=useState(false);
      return h('section',{id:'contact',className:'compact-contact section-pad'},h('div',{className:'section-shell compact-two'},
        h('div',{},h(Eyebrow,{},'QUESTIONS / NEXT STEPS'),h('h2',{className:'section-title title-white'},'NEED ',h('span',{className:'title-orange'},'HELP?')),
          h('p',{},'This demonstration shows how visitors could ask a question. Nothing is submitted or saved.')),
        h('div',{className:'compact-contact-links'},
          h(External,{href:site+'/contact',className:'btn btn-orange'},'OFFICIAL CONTACT ',h(Arrow,{diagonal:true})),
          h('button',{type:'button',className:'btn btn-outline',onClick:()=>setExpanded(v=>!v),'aria-expanded':expanded,'aria-controls':'question-demo'},expanded?'CLOSE DEMO':'TRY QUESTION DEMO ',h(Arrow,{})),
          expanded&&h('form',{id:'question-demo',className:'question-demo',onSubmit:e=>{e.preventDefault();setQuestion('');setSubmitted(true)}},
            h('label',{},'YOUR QUESTION (DEMO ONLY)',h('textarea',{required:true,maxLength:400,placeholder:'Example: Where can I find career training?',value:question,onChange:e=>{setQuestion(e.target.value);setSubmitted(false)}})),
            h('button',{type:'submit',className:'btn btn-orange'},'TEST QUESTION ',h(Arrow,{})),
            h('small',{},'Demonstration only. This does not send, save, or answer your question.')
          ),
          submitted&&h('p',{className:'question-result',role:'status'},'Demo complete. No message was sent or stored. For real help, use the organization links above or the official campaign contact page.')
        )
      ));
    }
    function App(){
      return h(React.Fragment,null,
        h(Header),
        h('main',{id:'main-content'},
          h(Hero),h(Ticker),h(PriorityHub),
          h(CompactMeet),h(CompactMedia),h(CompactEvents),h(CompactContact)
        ),
        h(Footer)
      );
    }
    return App;
  };
})(typeof window!=='undefined'?window:globalThis);
