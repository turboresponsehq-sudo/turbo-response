/* Canonical external resource dataset. These are third-party organizations, not campaign affiliates.
   Future additions: optional status, verifiedAt, expiresAt, applicationUrl — not used by this demo. */
(function(root){ root.kennResourceData = [
  {
    "id": "jobs",
    "slug": "jobs-economic-stability",
    "name": "Local jobs & economic stability",
    "label": "ECONOMY",
    "short": "Workforce alignment, career training, and local economic stability.",
    "detail": "The published platform discusses coordinated skills training, apprenticeships, workforce navigation, and local hiring outcomes.",
    "resources": [
      {
        "name": "WorkSource Fulton",
        "description": "Workforce development, employment assistance, and career training.",
        "url": "https://fultoncountyga.gov/inside-fulton-county/fulton-county-departments/worksource-fulton"
      }
    ]
  },
  {
    "id": "youth",
    "slug": "youth-pathways-career-access",
    "name": "Youth pathways & career access",
    "label": "YOUTH",
    "short": "Programs that connect young people to learning and career opportunities.",
    "detail": "The candidate’s published priorities include paid work-based learning, dual enrollment access, and digital workforce readiness.",
    "resources": [
      {
        "name": "Boys & Girls Clubs of Metro Atlanta",
        "description": "Youth development, mentoring, academic programs, and career readiness.",
        "url": "https://bgcma.org/"
      }
    ]
  },
  {
    "id": "safety",
    "slug": "community-safety-violence-prevention",
    "name": "Community safety & violence prevention",
    "label": "SAFETY",
    "short": "Community-based violence prevention and family support.",
    "detail": "The campaign identifies community-based violence prevention and safer neighborhoods as policy themes.",
    "resources": [
      {
        "name": "CHRIS 180",
        "description": "Community violence prevention and family support resources.",
        "url": "https://chris180.org/"
      }
    ]
  },
  {
    "id": "schools",
    "slug": "trauma-informed-schools",
    "name": "Trauma-informed, healing-centered schools",
    "label": "EDUCATION",
    "short": "Student support and safer, more supportive learning environments.",
    "detail": "The campaign lists trauma-informed, healing-centered schools as a priority for children, educators, and families.",
    "resources": [
      {
        "name": "Fulton County Schools",
        "description": "Student services, mental health information, and educational support resources.",
        "url": "https://www.fultonschools.org/"
      }
    ]
  },
  {
    "id": "housing",
    "slug": "affordable-housing-homeownership",
    "name": "Affordable housing & homeownership",
    "label": "HOUSING",
    "short": "Housing stability, homeownership, and displacement concerns.",
    "detail": "The candidate’s public materials discuss affordable housing, homeownership, and the displacement of longtime residents.",
    "resources": [
      {
        "name": "Georgia Dream Homeownership",
        "description": "Homebuyer financing and down-payment assistance information.",
        "url": "https://georgia.gov/apply-georgia-dream-homeownership-program"
      },
      {
        "name": "Atlanta Volunteer Lawyers Foundation",
        "description": "Eviction-related legal assistance and tenant resources.",
        "url": "https://avlf.org/programs/eviction-defense/"
      }
    ]
  },
  {
    "id": "health",
    "slug": "healthcare-mental-health-wellness",
    "name": "Healthcare, mental health & wellness",
    "label": "HEALTH",
    "short": "Connections to public health and behavioral health information.",
    "detail": "The campaign highlights barriers to healthcare access, mental-health resources, and broader community wellness.",
    "resources": [
      {
        "name": "Fulton County Board of Health",
        "description": "Public health services and preventive care information.",
        "url": "https://fultoncountyboh.com/"
      },
      {
        "name": "Fulton County Behavioral Health",
        "description": "Mental health and behavioral health resources.",
        "url": "https://www.fultoncountyga.gov/behavioralhealth"
      }
    ]
  }
]; })(typeof window!=="undefined"?window:globalThis);
