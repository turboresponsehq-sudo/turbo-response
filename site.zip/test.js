'use strict';
const {spawn}=require('node:child_process');const assert=require('node:assert/strict');
const srv=spawn(process.execPath,['server.js'],{env:{...process.env,PORT:'31777'},stdio:'ignore'});
const root='http://127.0.0.1:31777';
(async()=>{
 try{let ready=false;for(let i=0;i<40;i++){try{const r=await fetch(root+'/api/health');if(r.ok){ready=true;break}}catch{}await new Promise(r=>setTimeout(r,60))}assert(ready,'server ready');
 const h=await(await fetch(root+'/api/health')).json();assert(h.ok&&h.project==='ATL IMPACT');
 const ev=await(await fetch(root+'/api/v1/evidence')).json();assert(ev.statistics.length>=7&&ev.sources.length>=5);assert(ev.statistics.some(x=>x.id==='nicjr-total'&&x.value===512430838));
 const filtered=await(await fetch(root+'/api/v1/evidence?category=deaths')).json();assert(filtered.statistics.every(x=>x.category==='deaths'));
 const f=await(await fetch(root+'/api/v1/funding')).json();assert(f.funding.some(x=>x.stage==='Committed in resolution'));
 const a=await(await fetch(root+'/api/v1/ask',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({question:'What funding was committed?'})})).json();assert(a.sources.some(x=>x.id==='fulton2026')&&a.stored===false);
 const p=await fetch(root+'/');assert.equal(p.status,200);assert((await p.text()).includes('THE COST'));
 const js=await fetch(root+'/app.js');assert.equal(js.status,200);
 const blocked=await fetch(root+'/data/evidence.json');assert.equal(blocked.status,404);
 console.log('8 checks passed: server, evidence, source, filter, funding, ask, UI, private data isolation');
 }catch(e){console.error(e);process.exitCode=1}finally{srv.kill('SIGTERM')}
})();
