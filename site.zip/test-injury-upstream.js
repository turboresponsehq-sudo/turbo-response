'use strict';
// Offline test-only mock. Never loaded in normal Render startup.
const original=globalThis.fetch;
globalThis.fetch=async function(url,opts){
 const u=new URL(String(url));
 if(u.hostname==='georgiacivicdata.org'&&u.pathname.endsWith('/er_visits_by_cause/rows')){
   const year=Number(u.searchParams.get('year'));
   if(u.searchParams.get('cause')!=='accidental_shooting'||u.searchParams.get('demographic')!=='all'||u.searchParams.get('detail')!=='counties')return {ok:false,status:400};
   const rows=Array.from({length:159},(_,i)=>({year,county_fips:`13${String(i*2+1).padStart(3,'0')}`,cause:'accidental_shooting',demographic:'all',num_er_visits:i===0?null:i===1?0:i+1,er_visit_rate_per_100k:i===0?null:2.3,age_adjusted_er_visit_rate_per_100k:1.8}));
   return {ok:true,json:async()=>({data:rows,pagination:{has_more:false}})};
 }
 return original(url,opts);
}
