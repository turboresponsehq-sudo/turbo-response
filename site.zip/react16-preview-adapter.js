/* Offline preview compatibility shim for locally bundled React 16 UMD.
   Vite uses React 18's native hooks, so this adapter is NOT loaded in the Vite app. */
(function(){
  const original=React.createElement;
  const memo=new WeakMap();
  let current=null;
  React.Fragment='div';
  React.useState=function(initial){
    if(!current) throw Error('useState called outside preview component');
    const host=current, idx=host._hookCursor++;
    if(!(idx in host._hooks))host._hooks[idx]=typeof initial==='function'?initial():initial;
    const setValue=function(value){const previous=host._hooks[idx];host._hooks[idx]=typeof value==='function'?value(previous):value;host.setState(v=>({revision:v.revision+1}));};
    return [host._hooks[idx],setValue];
  };
  React.useEffect=function(){/* no global effects required for basic preview interactions */};
  React.createElement=function(type,props){
    let t=type;
    if(typeof type==='function' && !(type.prototype&&type.prototype.isReactComponent)){
      if(!memo.has(type)){
        class FunctionalHost extends React.Component{
          constructor(p){super(p);this.state={revision:0};this._hooks=[];this._hookCursor=0;}
          render(){const old=current;current=this;this._hookCursor=0;let result;try{result=type(this.props)}finally{current=old;}return result;}
        }
        memo.set(type,FunctionalHost);
      }
      t=memo.get(type);
    }
    const a=[t,props].concat(Array.prototype.slice.call(arguments,2));
    return original.apply(React,a);
  };
})();
