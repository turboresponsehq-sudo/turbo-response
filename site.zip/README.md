# ATL IMPACT — Evidence-backed interactive public-interest platform (prototype)

Version 0.1 / Nov. 22, 2026. Independent product prototype, not affiliated with Kenn Collier, his nonprofit, a campaign, or any government body.

## Features
- One-screen-at-a-time navigational experience, mobile and desktop.
- Live source-backed Evidence API with category filtering.
- Stakeholder economic exposure Money Map.
- Source-linked Follow the Money funding ledger.
- Funding-to-cost scenario slider clearly labeled illustrative, not predicted/causal savings.
- Interactive family and survivor pathways.
- Guided source assistant API, no model calls and no conversation storage.
- Click-through source ledger, no images of victims or personal data collection.

## Architecture
Node.js built-in HTTP server (zero npm dependencies), HTML/CSS/vanilla JavaScript, structured JSON data repository. Routes:
`GET /api/health`, `GET /api/v1/evidence?category=...`, `GET /api/v1/stakeholders`, `GET /api/v1/funding`, `GET /api/v1/resources`, `POST /api/v1/ask`.

Run: `npm start` (port 3000 by default); test: `npm test`. No passwords or external API keys required.

## Data governance
No incident-level names/photos, exact shooting addresses, voter data, PII or client intake. Verified-source data records carry explicit period, geography, unit and limitations. The projections do not forecast reduced crime or guaranteed return on investments. Funding statuses differentiate commitment from award and assistance benefit.

## Next steps (not represented as shipped)
Add agency-level firearm-specific 2021–2026 annual/age-group records with source metadata and suppression-aware disclosure; introduce protected content/consent workflow before publishing any memorial imagery; expand evidence-update pipeline; optionally connect an approved RAG assistant after validating privacy and costs; obtain independent program evaluations before making causal impact claims.
