# Georgia Impact Intelligence — Map-First Interactive Prototype V2

Independent public-interest demonstration for review with Kenn Collier. This application is isolated from the production Turbo Response website and from the earlier Kenn page preview.

## What is operational
- Georgia county map showing 159 counties, hover, touch/click, county search, quick links, accessible keyboard selections, district research view when current boundaries can be retrieved, map zoom, presentation mode.
- Historical year selection (2019–2024 final CDC county MIOV records); 2025–2026 displayed explicitly as unavailable rather than zero.
- County-specific firearm deaths (all intents) and firearm homicide deaths via a public, read-only Georgia Civic Data endpoint using CDC MIOV county-of-residence data. Server caches each year for 6 hours. No API key, external monitoring or new paid service.
- 2019–2024 county comparison on demand. Death count 1–9 suppression remains null/withheld, and modeled rates are labeled.
- Separate Fulton County Medical Examiner 2024 record, Fulton FY2027 funding announcement, and Atlanta NICJR economic model (not county-level expenditure).
- 7-, 14-, and 30-day prompt builder for researcher-led report production. It does not run background research or publish unverified content.

## V3 add-on: hospital-treated firearm injuries, correctly scoped
- New `GET /api/v1/county-injury-visits?year=2024` endpoint (2019–2025), read-only no-key Georgia Civic Data API dataset `er_visits_by_cause`; filters `cause=accidental_shooting`, `demographic=all` at county residence geography. Automatic 6-hour in-memory cache; no private records.
- County detail shows the exact *accidental-shooting emergency visits NOT ending in admission* count and crude rate when available. These figures count ER visits, not distinct people, not all nonfatal shootings, and not an entire county's gun injuries. Admitted patients are not in this specific OASIS ER measure.
- A separate **all nonfatal firearm injuries: Not available** item is intentional because the current GCD OASIS cause categories do not isolate assault-by-firearm from other assault; do not pass broad assault data off as shooting injuries.
- A link to the official GA DPH FASTER/AVERT firearm-injury dashboard provides broader Georgia context, but its Tableau data are not yet integrated into the prototype, and source may be unavailable. This is a scope-valid partial feature, not a statewide full injury feed.
- OASIS reference: https://georgiacivicdata.org/api/datasets/health/er_visits_by_cause , official https://oasis.state.ga.us/dtt/er and https://dph.georgia.gov/faster-ga . No guarantee of external availability.

## What is NOT present
- Live or complete 2025/2026 county shooting incident counts.
- Comprehensive county-specific nonfatal firearm injury, grant-award, program-outcome, or economic data.
- Guaranteed availability of external public-data endpoints. When a provider fails, statistics show unavailable; no number is invented.
- Verified incident totals by House district; county-level records may not be represented as district totals.

## External provenance
- CDC MIOV via Georgia Civic Data, Firearm Deaths: https://georgiacivicdata.org/api/datasets/health/firearm_deaths
- CDC MIOV via Georgia Civic Data, Homicide Deaths: https://georgiacivicdata.org/api/datasets/health/homicide_deaths
- Source upstream: https://data.cdc.gov/d/psx4-wq38
- Fulton County dated announcement (2024 count, 2027 commitment): https://www.fultoncountyga.gov/News/2026/11/20/Fulton-County-Board-of-Commissioners-Commits-500000-to-Gun-Violence-Intervention
- Map geometry: Census TIGERweb public map layers, with historical fallback clearly labeled.
- Research records and citations in data/evidence.json.

### Important definitions
- CDC mortality data counts deaths among residents of each county, wherever death occurred. Fulton Medical Examiner counts deaths under its investigation jurisdiction; these should not be equated or summed.
- 'Firearm deaths, all intents' already includes 'firearm homicide deaths'. Do not add columns.
- CDC suppresses county-year counts of 1–9; the associated displayed death rate may be Bayesian modeled, not observed.
- Missing is **not** zero. Modeled economic impact is not annual actual government spending.

## Deploy
Render service: atl-impact-intelligence-demo (standalone), branch prototype/atl-impact-2026-v1, auto-deploy disabled. Build: unzip -oq site.zip -d app && test -f app/server.js. Start: node app/server.js.

## Source licensing
Georgia Civic Data normalized data/documentation CC BY 4.0; credit Georgia Civic Data and original source (CDC). No individual victim records are stored or shown.
